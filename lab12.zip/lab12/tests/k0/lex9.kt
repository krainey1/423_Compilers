// lex9.kt: assignment operators
fun main() {
    var x = 10
    x += 5
    x -= 2
    x *= 3
    x /= 2
    x %= 4
}
