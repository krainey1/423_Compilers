fun foo()
fun main() {
    foo()
}
